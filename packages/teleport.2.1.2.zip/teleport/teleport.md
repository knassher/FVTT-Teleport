## Teleport

* **Author**: knassher#9922, 
* **Version**: 2.0.0
* **Foundry VTT Compatibility**: 0.5.5
* **System Compatibility (If applicable)**: Universal
* **Module Requirement(s)**: Furnace
* **Module Conflicts**: None known
* **Translation Support**: -

### Link(s) to Module
* [https://github.com/knassher/FVTT-Teleport) 
* Manifest: [https://raw.githubusercontent.com/knassher/FVTT-Teleport/master/module.json](https://raw.githubusercontent.com/knassher/FVTT-Teleport/master/module.json) 

### Description
A module for FVTT to teleport tokens between two points within a scene or different scenes.

---